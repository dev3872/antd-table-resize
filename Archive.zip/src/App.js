import AntdTable from './AntdTable';
import "./App.scss"
import Demo from './Resize';
import ResizeableTitle from './Resize';
import Resize from './Resize';
function App() {
  return (
    <AntdTable/>
    //<Demo/>
  );
}

export default App;
